#!/usr/bin/env python3
"""
hrm_depth_a100_audit_v3.py
==========================

Fixed version: unbatched MC log-likelihood scoring to avoid IndexError
at non-default recurrence depths (deep_H, maximum).

Change from v1: choice_loglikelihoods processes one choice at a time
instead of batching all choices. This matches the single-sequence path
that model.generate() uses (which works at all depths).

Usage:
    python hrm_depth_a100_audit_v3.py \
        --model_id sapientinc/HRM-Text-1B \
        --out_dir ./hrm_depth_v2 \
        --seeds 42 43 44 \
        --depths minimal shallow half default deep_H maximum

    # Resume crashed run (skips completed seed/depth/benchmark combos):
    python hrm_depth_a100_audit_v3.py --skip_existing --out_dir ./hrm_depth_v2

    # Fast smoke test:
    python hrm_depth_a100_audit_v3.py --smoke
"""

import argparse
import gc
import hashlib
import json
import math
import os
import random
import re
import sys
import time
import traceback
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

warnings.filterwarnings("ignore")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

# --- Out-of-the-box environment bootstrap --------------------------------
# HRM-Text is supported *natively* by transformers (the `hrm_text` model type
# was added in transformers 5.9.0); the HF checkpoint ships no remote modeling
# code, so an older transformers cannot build it. If the installed transformers
# lacks `hrm_text`, auto-upgrade to >=5.9.0 and relaunch so the script runs with
# zero manual setup. (huggin.py self-pins transformers 4.49.0 for Huginn, which
# needs the opposite; the two scripts manage their own versions independently.)
# Also disable hf_transfer so downloads don't require the optional package.
os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "0")
if os.environ.get("_REPRO_BOOTSTRAPPED") != "1":
    try:
        from transformers.models.auto.configuration_auto import CONFIG_MAPPING_NAMES
        _has_hrm = "hrm_text" in CONFIG_MAPPING_NAMES
    except Exception:
        _has_hrm = False
    if not _has_hrm:
        import subprocess as _sp
        print("[setup] transformers lacks native hrm_text support; installing "
              ">=5.9.0 and relaunching...", flush=True)
        _sp.check_call([sys.executable, "-m", "pip", "install", "-q", "-U",
                        "transformers>=5.9.0"])
        os.environ["_REPRO_BOOTSTRAPPED"] = "1"
        os.execv(sys.executable, [sys.executable] + sys.argv)
    os.environ["_REPRO_BOOTSTRAPPED"] = "1"

import torch
import numpy as np
import pandas as pd
from datasets import load_dataset
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer


# -------------------------
# Depth settings
# -------------------------

DEPTH_SETTINGS: Dict[str, Dict[str, Any]] = {
    "minimal": {"name": "minimal", "H": 1, "L": 1, "passes": 2, "eff_layers": 16},
    "shallow": {"name": "shallow", "H": 1, "L": 3, "passes": 4, "eff_layers": 32},
    "half":    {"name": "half",    "H": 2, "L": 1, "passes": 4, "eff_layers": 32},
    "default": {"name": "default", "H": 2, "L": 3, "passes": 8, "eff_layers": 64},
    "intermediate": {"name": "intermediate", "H": 2, "L": 2, "passes": 6, "eff_layers": 48},
    "deep_H":  {"name": "deep_H",  "H": 4, "L": 3, "passes": 16, "eff_layers": 128},
    "maximum": {"name": "maximum", "H": 4, "L": 6, "passes": 28, "eff_layers": 224},
}


# -------------------------
# Logging / reproducibility
# -------------------------

def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def stable_id(*parts: Any) -> str:
    raw = "||".join(str(p) for p in parts)
    return hashlib.md5(raw.encode("utf-8")).hexdigest()[:12]


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def save_json(path: Path, obj: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def disable_kv_cache(model) -> None:
    """
    Disable KV-cache globally.

    This is important for HRM variable-depth experiments. When H_cycles/L_cycles
    are changed beyond the checkpoint default, Transformers' past_key_values cache
    can be allocated for the wrong effective recurrence depth, causing:
        IndexError: list index out of range
    inside transformers/cache_utils.py.

    Disabling cache is slower, but it makes variable-depth scoring correct.
    """
    try:
        model.config.use_cache = False
    except Exception:
        pass
    try:
        model.generation_config.use_cache = False
    except Exception:
        pass


@torch.inference_mode()
def forward_no_cache(model, **kwargs):
    """
    Forward pass with use_cache=False, with a safe fallback for unusual remote-code
    signatures.
    """
    try:
        return model(**kwargs, use_cache=False)
    except TypeError:
        return model(**kwargs)


def infer_num_layers_per_stack(model) -> Optional[int]:
    """
    Infer the real number of transformer blocks inside each HRM stack.

    HF HRM-Text uses:
        effective_num_hidden_layers = num_layers_per_stack * H_cycles * (L_cycles + 1)

    When we change H_cycles/L_cycles at inference time, DynamicCache needs the
    effective num_hidden_layers updated too, otherwise attention may index beyond
    the allocated cache and crash with:
        IndexError: list index out of range
    """
    cfg = model.config

    nps = getattr(cfg, "num_layers_per_stack", None)
    if nps is not None:
        try:
            return int(nps)
        except Exception:
            pass

    # Fallback: infer from the current config before we mutate it.
    nh = getattr(cfg, "num_hidden_layers", None)
    h = getattr(cfg, "H_cycles", None)
    l = getattr(cfg, "L_cycles", None)
    if nh is not None and h is not None and l is not None:
        denom = int(h) * (int(l) + 1)
        if denom > 0 and int(nh) % denom == 0:
            return int(nh) // denom

    # Last fallback for the released HRM-Text-1B default:
    # default effective layers are 64 with H=2, L=3 -> 64 / 8 = 8.
    if nh is not None:
        try:
            nh = int(nh)
            if nh in (64, 128, 224):
                return 8
        except Exception:
            pass

    return None


def update_hrm_effective_layers_for_depth(model, h: int, l: int) -> None:
    """
    Update config.num_hidden_layers after changing HRM recurrence depth.

    This is the important v3 fix. HRM-Text's DynamicCache allocation depends on
    config.num_hidden_layers, which must equal:
        num_layers_per_stack * H_cycles * (L_cycles + 1)
    """
    cfg = model.config

    nps = getattr(cfg, "_audit_num_layers_per_stack", None)
    if nps is None:
        nps = infer_num_layers_per_stack(model)
        if nps is not None:
            try:
                cfg._audit_num_layers_per_stack = int(nps)
            except Exception:
                pass

    if nps is None:
        log("WARNING: could not infer num_layers_per_stack; cache depth may still fail.")
        return

    effective_layers = int(nps) * int(h) * (int(l) + 1)

    if hasattr(cfg, "num_hidden_layers"):
        cfg.num_hidden_layers = effective_layers

    # Some HF configs keep nested configs. Update any obvious nested config too.
    for nested_name in ["text_config", "decoder_config", "model_config"]:
        nested = getattr(cfg, nested_name, None)
        if nested is not None and hasattr(nested, "num_hidden_layers"):
            try:
                nested.num_hidden_layers = effective_layers
            except Exception:
                pass

    # Keep cache disabled for safety, but the layer count must still be correct
    # because HRM-Text internally constructs/updates DynamicCache.
    disable_kv_cache(model)

    try:
        log(f"HRM cache-depth config: num_layers_per_stack={int(nps)}, "
            f"H={int(h)}, L={int(l)}, effective num_hidden_layers={effective_layers}")
    except Exception:
        pass


# -------------------------
# Model loading and depth setting
# -------------------------

def load_model_and_tokenizer(model_id: str, device: str, force_float16: bool = False):
    log(f"Loading tokenizer: {model_id}")
    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    if device.startswith("cuda") and torch.cuda.is_available():
        if force_float16:
            dtype = torch.float16
        else:
            dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    else:
        dtype = torch.float32

    log(f"Loading model: {model_id} on {device} with dtype={dtype}")

    try:
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            dtype=dtype,
            device_map={"": device} if device.startswith("cuda") else None,
            trust_remote_code=True,
        )
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            torch_dtype=dtype,
            device_map={"": device} if device.startswith("cuda") else None,
            trust_remote_code=True,
        )

    if not device.startswith("cuda"):
        model.to(device)

    model.eval()
    disable_kv_cache(model)

    # Store the base per-stack layer count before any depth mutation.
    nps = infer_num_layers_per_stack(model)
    if nps is not None:
        try:
            model.config._audit_num_layers_per_stack = int(nps)
            log(f"Inferred HRM num_layers_per_stack={int(nps)}")
        except Exception:
            pass

    return model, tokenizer


def find_recurrence_module(model):
    candidates = []
    for name, module in model.named_modules():
        if hasattr(module, "H_cycles") and hasattr(module, "L_cycles"):
            candidates.append((name, module))

    if candidates:
        log("Found recurrence modules:")
        for name, module in candidates:
            log(f"  {name or '<root>'}: H_cycles={getattr(module, 'H_cycles', None)}, "
                f"L_cycles={getattr(module, 'L_cycles', None)}")
        return [m for _, m in candidates]

    if hasattr(model.config, "H_cycles") and hasattr(model.config, "L_cycles"):
        log(f"Using model.config recurrence: H_cycles={model.config.H_cycles}, "
            f"L_cycles={model.config.L_cycles}")
        return []

    raise RuntimeError("Could not find H_cycles/L_cycles on model modules or config.")


def set_depth(model, rec_modules: Sequence[Any], h: int, l: int) -> None:
    """
    Set HRM recurrence depth and update effective cache layer count.

    v3 fix:
    Changing only H_cycles/L_cycles is not enough. HRM-Text's attention uses
    self.layer_idx + cycle_offset into DynamicCache, so config.num_hidden_layers
    must also be expanded to match the new effective depth.
    """
    for module in rec_modules:
        module.H_cycles = h
        module.L_cycles = l

    if hasattr(model.config, "H_cycles"):
        model.config.H_cycles = h
    if hasattr(model.config, "L_cycles"):
        model.config.L_cycles = l

    update_hrm_effective_layers_for_depth(model, h, l)


def verify_depth(model, rec_modules: Sequence[Any], expected_h: int,
                 expected_l: int) -> Dict[str, Any]:
    observed = []
    for module in rec_modules:
        observed.append({
            "module": type(module).__name__,
            "H_cycles": getattr(module, "H_cycles", None),
            "L_cycles": getattr(module, "L_cycles", None),
        })

    config_h = getattr(model.config, "H_cycles", None)
    config_l = getattr(model.config, "L_cycles", None)
    config_nh = getattr(model.config, "num_hidden_layers", None)

    ok_modules = all(
        x["H_cycles"] == expected_h and x["L_cycles"] == expected_l
        for x in observed
    ) if observed else True
    ok_config = True
    if config_h is not None:
        ok_config = ok_config and (config_h == expected_h)
    if config_l is not None:
        ok_config = ok_config and (config_l == expected_l)

    return {
        "expected_H": expected_h, "expected_L": expected_l,
        "config_H": config_h, "config_L": config_l,
        "config_num_hidden_layers": config_nh,
        "modules": observed, "ok": bool(ok_modules and ok_config),
    }


# -------------------------
# Dataset loading
# -------------------------

def select_seeded(ds, n: int, seed: int):
    if n <= 0:
        return []
    n = min(n, len(ds))
    return ds.shuffle(seed=seed).select(range(n))


def normalize_number_str(s: str) -> Optional[float]:
    if s is None:
        return None
    s = str(s).strip().replace(",", "").replace("$", "").replace("%", "")
    frac = re.fullmatch(r"(-?\d+)\s*/\s*(-?\d+)", s)
    if frac:
        den = float(frac.group(2))
        if den == 0:
            return None
        return float(frac.group(1)) / den
    try:
        return float(s)
    except Exception:
        return None


def load_gsm8k(n: int, seed: int) -> List[Dict[str, Any]]:
    ds = load_dataset("openai/gsm8k", "main", split="test")
    ds = select_seeded(ds, n, seed)
    out = []
    for i, ex in enumerate(ds):
        answer_text = ex["answer"]
        gold = answer_text.split("####")[-1].strip().replace(",", "")
        out.append({
            "example_id": stable_id("gsm8k", seed, ex["question"], gold),
            "row_index": i, "question": ex["question"],
            "answer": gold, "answer_full": answer_text,
        })
    return out


def load_arc_challenge(n: int, seed: int) -> List[Dict[str, Any]]:
    ds = load_dataset("allenai/ai2_arc", "ARC-Challenge", split="test")
    ds = select_seeded(ds, n, seed)
    out = []
    for i, ex in enumerate(ds):
        choices = list(zip(ex["choices"]["label"], ex["choices"]["text"]))
        out.append({
            "example_id": stable_id("arc-c", seed, ex["question"], ex["answerKey"]),
            "row_index": i, "question": ex["question"],
            "choices": choices, "answer": ex["answerKey"],
        })
    return out


def load_hellaswag(n: int, seed: int) -> List[Dict[str, Any]]:
    ds = load_dataset("Rowan/hellaswag", split="validation")
    ds = select_seeded(ds, n, seed)
    out = []
    for i, ex in enumerate(ds):
        out.append({
            "example_id": stable_id("hellaswag", seed, ex["ctx"], ex["label"]),
            "row_index": i, "context": ex["ctx"],
            "choices": ex["endings"], "answer": int(ex["label"]),
        })
    return out


def load_mmlu(n: int, seed: int) -> List[Dict[str, Any]]:
    ds = load_dataset("cais/mmlu", "all", split="test")
    ds = select_seeded(ds, n, seed)
    labels = ["A", "B", "C", "D"]
    out = []
    for i, ex in enumerate(ds):
        out.append({
            "example_id": stable_id("mmlu", seed, ex["question"], ex["answer"],
                                     ex.get("subject", "")),
            "row_index": i, "question": ex["question"],
            "subject": ex.get("subject", ""),
            "choices": list(zip(labels, ex["choices"])),
            "answer": labels[int(ex["answer"])],
        })
    return out


def load_boolq(n: int, seed: int) -> List[Dict[str, Any]]:
    ds = load_dataset("google/boolq", split="validation")
    ds = select_seeded(ds, n, seed)
    out = []
    for i, ex in enumerate(ds):
        out.append({
            "example_id": stable_id("boolq", seed, ex["passage"], ex["question"],
                                     ex["answer"]),
            "row_index": i, "passage": ex["passage"],
            "question": ex["question"], "answer": bool(ex["answer"]),
        })
    return out


def load_all_benchmarks(args, seed: int) -> Dict[str, List[Dict[str, Any]]]:
    log(f"Loading benchmarks for seed={seed}")
    benchmarks = {}
    loaders = [
        ("GSM8K", load_gsm8k, args.n_gsm8k),
        ("ARC-C", load_arc_challenge, args.n_arc),
        ("HellaSwag", load_hellaswag, args.n_hellaswag),
        ("MMLU", load_mmlu, args.n_mmlu),
        ("BoolQ", load_boolq, args.n_boolq),
    ]
    for name, loader, n in loaders:
        if n <= 0:
            continue
        try:
            t0 = time.time()
            benchmarks[name] = loader(n, seed)
            log(f"  {name}: {len(benchmarks[name])} examples loaded in "
                f"{time.time() - t0:.1f}s")
        except Exception as e:
            log(f"  WARNING: failed loading {name}: {repr(e)}")
    return benchmarks


# -------------------------
# Evaluation formatting
# -------------------------

def gsm8k_prompt(question: str) -> str:
    return (
        "Solve the math problem. Show the calculation briefly. "
        "End with: The answer is <number>.\n\n"
        "Q: There are 15 trees in the grove. Grove workers will plant trees today. "
        "After they are done, there will be 21 trees. How many trees did the grove "
        "workers plant today?\n"
        "A: There are 21 - 15 = 6 trees planted. The answer is 6.\n\n"
        "Q: If there are 3 cars in the parking lot and 2 more cars arrive, "
        "how many cars are in the parking lot now?\n"
        "A: There are 3 + 2 = 5 cars. The answer is 5.\n\n"
        f"Q: {question}\nA:"
    )


def fmt_arc(ex):
    context = f"Question: {ex['question']}\nAnswer:"
    labels = [label for label, _ in ex["choices"]]
    choices = [f" {text}" for _, text in ex["choices"]]
    gold = labels.index(ex["answer"])
    return context, choices, gold, labels


def fmt_hellaswag(ex):
    labels = [str(i) for i in range(len(ex["choices"]))]
    return ex["context"], [f" {e}" for e in ex["choices"]], int(ex["answer"]), labels


def fmt_mmlu(ex):
    context = f"Question: {ex['question']}\nAnswer:"
    labels = [label for label, _ in ex["choices"]]
    choices = [f" {text}" for _, text in ex["choices"]]
    gold = labels.index(ex["answer"])
    return context, choices, gold, labels


def fmt_boolq(ex):
    passage = ex["passage"]
    if len(passage) > 1000:
        passage = passage[:1000]
    context = f"{passage}\nQuestion: {ex['question']}?\nAnswer:"
    choices = [" yes", " no"]
    labels = ["yes", "no"]
    gold = 0 if ex["answer"] else 1
    return context, choices, gold, labels


FORMATTERS = {
    "ARC-C": fmt_arc,
    "HellaSwag": fmt_hellaswag,
    "MMLU": fmt_mmlu,
    "BoolQ": fmt_boolq,
}


# -------------------------
# Inference helpers
# -------------------------

@torch.inference_mode()
def generate_text(model, tokenizer, prompt: str, max_new_tokens: int,
                  max_prompt_len: int) -> Tuple[str, Dict[str, Any]]:
    enc = tokenizer(prompt, return_tensors="pt", truncation=True,
                    max_length=max_prompt_len).to(model.device)
    prompt_tokens = int(enc["input_ids"].shape[1])
    t0 = time.time()
    out = model.generate(
        **enc, max_new_tokens=max_new_tokens, do_sample=False,
        pad_token_id=tokenizer.pad_token_id,
        eos_token_id=tokenizer.eos_token_id,
        use_cache=False,
    )
    elapsed = time.time() - t0
    gen_ids = out[0][enc["input_ids"].shape[1]:]
    text = tokenizer.decode(gen_ids, skip_special_tokens=True)
    meta = {"prompt_tokens": prompt_tokens,
            "generated_tokens": int(gen_ids.shape[0]),
            "elapsed_sec": elapsed}
    return text, meta


@torch.inference_mode()
def choice_loglikelihoods(
    model,
    tokenizer,
    context: str,
    continuations: List[str],
    max_len: int,
) -> Tuple[List[float], Dict[str, Any]]:
    """
    Average log-likelihood per continuation token for each candidate.

    v2 FIX: Processes one choice at a time (unbatched) to avoid IndexError
    inside HRM's recurrent forward pass at non-default depth settings.
    The batched version crashes because HRM's internal recurrence structures
    have shape assumptions that break with padded multi-sequence batches
    at non-trained H_cycles/L_cycles values.

    Single-sequence forward passes work at all depths (same path as generate()).
    """
    ctx_enc = tokenizer(context, add_special_tokens=True)
    ctx_len = len(ctx_enc["input_ids"])

    scores = []
    valid_token_counts = []
    total_elapsed = 0.0
    truncated_any = False
    max_total_tokens = 0

    for cont in continuations:
        full_text = context + cont
        enc = tokenizer(
            full_text,
            add_special_tokens=True,
            truncation=True,
            max_length=max_len,
            return_tensors="pt",
        ).to(model.device)

        input_ids = enc["input_ids"]           # [1, seq_len]
        attention_mask = enc["attention_mask"]  # [1, seq_len]

        actual_len = int(attention_mask.sum().item())
        max_total_tokens = max(max_total_tokens, actual_len)

        full_ids = tokenizer(full_text, add_special_tokens=True)["input_ids"]
        if len(full_ids) > max_len:
            truncated_any = True

        t0 = time.time()
        outputs = forward_no_cache(
            model, input_ids=input_ids, attention_mask=attention_mask)
        total_elapsed += time.time() - t0

        logits = outputs.logits  # [1, seq_len, vocab]
        shift_logits = logits[:, :-1, :]
        shift_labels = input_ids[:, 1:]

        log_probs = torch.log_softmax(shift_logits, dim=-1)
        token_lp = log_probs.gather(
            dim=-1, index=shift_labels.unsqueeze(-1)).squeeze(-1)

        # Score only continuation tokens (after context)
        start = max(0, ctx_len - 1)
        end = max(start, actual_len - 1)
        lp_slice = token_lp[0, start:end]

        if lp_slice.numel() == 0:
            scores.append(float("-inf"))
            valid_token_counts.append(0)
        else:
            scores.append(float(lp_slice.mean().detach().cpu().item()))
            valid_token_counts.append(int(lp_slice.numel()))

    meta = {
        "elapsed_sec": total_elapsed,
        "ctx_tokens": ctx_len,
        "max_total_tokens": max_total_tokens,
        "truncated_any": bool(truncated_any),
        "valid_token_counts": valid_token_counts,
    }
    return scores, meta


# -------------------------
# GSM8K parsing
# -------------------------

NUMBER_RE = r"[-+]?\d[\d,]*(?:\.\d+)?(?:\s*/\s*[-+]?\d[\d,]*)?"


def parse_gsm8k_answer(output: str) -> Tuple[Optional[float], str, Optional[str]]:
    if output is None:
        return None, "empty_output", None
    txt = output.strip()
    if not txt:
        return None, "empty_output", None

    patterns = [
        rf"[Tt]he answer is\s*({NUMBER_RE})",
        rf"[Aa]nswer\s*[:=]\s*({NUMBER_RE})",
        rf"####\s*({NUMBER_RE})",
    ]
    for pat in patterns:
        m = re.search(pat, txt)
        if m:
            raw = m.group(1)
            val = normalize_number_str(raw)
            if val is not None:
                return val, "explicit_answer", raw

    nums = re.findall(NUMBER_RE, txt)
    if nums:
        raw = nums[-1]
        val = normalize_number_str(raw)
        if val is not None:
            return val, "last_number", raw
        return None, "parse_error", raw

    return None, "no_number", None


def compare_numeric(pred: Optional[float], gold_text: str,
                    atol: float = 1e-2) -> bool:
    gold = normalize_number_str(gold_text)
    if pred is None or gold is None:
        return False
    return abs(float(pred) - float(gold)) <= atol


# -------------------------
# Evaluation functions
# -------------------------

def evaluate_gsm8k(model, tokenizer, data, seed, depth_name, depth_cfg, args):
    rows = []
    for ex in tqdm(data, desc=f"GSM8K seed={seed} depth={depth_name}", leave=False):
        prompt = gsm8k_prompt(ex["question"])
        try:
            output, meta = generate_text(model, tokenizer, prompt,
                                          max_new_tokens=args.max_new_tokens,
                                          max_prompt_len=args.max_prompt_len)
            pred_float, parser_status, matched_text = parse_gsm8k_answer(output)
            correct = compare_numeric(pred_float, ex["answer"],
                                       atol=args.numeric_atol)
            rows.append({
                "seed": seed, "benchmark": "GSM8K", "depth": depth_name,
                "H_cycles": depth_cfg["H"], "L_cycles": depth_cfg["L"],
                "passes": depth_cfg["passes"], "eff_layers": depth_cfg["eff_layers"],
                "example_id": ex["example_id"], "row_index": ex["row_index"],
                "gold": ex["answer"],
                "pred": "" if pred_float is None else pred_float,
                "pred_label": "" if pred_float is None else str(pred_float),
                "correct": bool(correct), "parser_status": parser_status,
                "matched_text": matched_text or "", "score_gap": "",
                "prompt_tokens": meta["prompt_tokens"],
                "generated_tokens": meta["generated_tokens"],
                "elapsed_sec": meta["elapsed_sec"], "truncated": False,
                "question_or_context": ex["question"], "raw_output": output,
            })
        except Exception as e:
            rows.append({
                "seed": seed, "benchmark": "GSM8K", "depth": depth_name,
                "H_cycles": depth_cfg["H"], "L_cycles": depth_cfg["L"],
                "passes": depth_cfg["passes"], "eff_layers": depth_cfg["eff_layers"],
                "example_id": ex["example_id"], "row_index": ex["row_index"],
                "gold": ex["answer"], "pred": "", "pred_label": "",
                "correct": False, "parser_status": "exception",
                "matched_text": "", "score_gap": "",
                "prompt_tokens": "", "generated_tokens": "",
                "elapsed_sec": "", "truncated": "",
                "question_or_context": ex["question"],
                "raw_output": f"EXCEPTION: {repr(e)}\n{traceback.format_exc()}",
            })
    return rows


def evaluate_mcq(model, tokenizer, data, benchmark, seed, depth_name,
                 depth_cfg, args):
    rows = []
    formatter = FORMATTERS[benchmark]

    for ex in tqdm(data, desc=f"{benchmark} seed={seed} depth={depth_name}",
                   leave=False):
        try:
            context, choices, gold_idx, labels = formatter(ex)
            scores, meta = choice_loglikelihoods(
                model, tokenizer, context, choices,
                max_len=args.max_eval_len)

            pred_idx = int(np.argmax(scores))
            sorted_scores = sorted(scores, reverse=True)
            score_gap = (sorted_scores[0] - sorted_scores[1]
                         if len(sorted_scores) > 1 else 0.0)

            rows.append({
                "seed": seed, "benchmark": benchmark, "depth": depth_name,
                "H_cycles": depth_cfg["H"], "L_cycles": depth_cfg["L"],
                "passes": depth_cfg["passes"], "eff_layers": depth_cfg["eff_layers"],
                "example_id": ex["example_id"], "row_index": ex["row_index"],
                "gold": labels[gold_idx], "pred": labels[pred_idx],
                "pred_label": labels[pred_idx],
                "correct": bool(pred_idx == gold_idx),
                "parser_status": "mcq_ll", "matched_text": "",
                "score_gap": score_gap,
                "prompt_tokens": meta["ctx_tokens"], "generated_tokens": 0,
                "elapsed_sec": meta["elapsed_sec"],
                "truncated": bool(meta["truncated_any"]),
                "question_or_context": context[:1000],
                "raw_output": json.dumps({
                    "choices": choices, "labels": labels, "scores": scores,
                    "valid_token_counts": meta["valid_token_counts"],
                }, ensure_ascii=False),
            })
        except Exception as e:
            rows.append({
                "seed": seed, "benchmark": benchmark, "depth": depth_name,
                "H_cycles": depth_cfg["H"], "L_cycles": depth_cfg["L"],
                "passes": depth_cfg["passes"], "eff_layers": depth_cfg["eff_layers"],
                "example_id": ex.get("example_id", ""),
                "row_index": ex.get("row_index", ""),
                "gold": "", "pred": "", "pred_label": "",
                "correct": False, "parser_status": "exception",
                "matched_text": "", "score_gap": "",
                "prompt_tokens": "", "generated_tokens": 0,
                "elapsed_sec": "", "truncated": "",
                "question_or_context": "",
                "raw_output": f"EXCEPTION: {repr(e)}\n{traceback.format_exc()}",
            })
    return rows


# -------------------------
# Statistics
# -------------------------

def bootstrap_ci_binary(values, n_boot=3000, seed=123, alpha=0.05):
    arr = np.asarray(values, dtype=float)
    if len(arr) == 0:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    means = [float(arr[rng.integers(0, len(arr), size=len(arr))].mean())
             for _ in range(n_boot)]
    return (float(np.percentile(means, 100 * alpha / 2)),
            float(np.percentile(means, 100 * (1 - alpha / 2))))


def bootstrap_ci_numeric(values, n_boot=3000, seed=123, alpha=0.05):
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    means = [float(arr[rng.integers(0, len(arr), size=len(arr))].mean())
             for _ in range(n_boot)]
    return (float(np.percentile(means, 100 * alpha / 2)),
            float(np.percentile(means, 100 * (1 - alpha / 2))))


def paired_bootstrap_delta(a, b, n_boot=3000, seed=123, alpha=0.05):
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    assert len(aa) == len(bb)
    if len(aa) == 0:
        return {"delta": float("nan"), "ci_low": float("nan"),
                "ci_high": float("nan"), "p_delta_le_0": float("nan")}
    d = aa - bb
    rng = np.random.default_rng(seed)
    means = np.array([float(d[rng.integers(0, len(d), size=len(d))].mean())
                      for _ in range(n_boot)])
    return {
        "delta": float(d.mean()),
        "ci_low": float(np.percentile(means, 100 * alpha / 2)),
        "ci_high": float(np.percentile(means, 100 * (1 - alpha / 2))),
        "p_delta_le_0": float((means <= 0).mean()),
    }


def sign_test_p_value(a, b):
    wins = losses = ties = 0
    for x, y in zip(a, b):
        if x and not y:
            wins += 1
        elif y and not x:
            losses += 1
        else:
            ties += 1
    n = wins + losses
    if n == 0:
        return {"wins": wins, "losses": losses, "ties": ties, "p_two_sided": 1.0}
    k = min(wins, losses)
    cdf = sum(math.comb(n, i) * (0.5 ** n) for i in range(k + 1))
    return {"wins": wins, "losses": losses, "ties": ties,
            "p_two_sided": float(min(1.0, 2.0 * cdf))}


def build_summary(per_ex, args):
    rows = []
    for (seed, benchmark, depth), g in per_ex.groupby(
            ["seed", "benchmark", "depth"], dropna=False):
        correct = g["correct"].astype(bool).tolist()
        acc = float(np.mean(correct)) if correct else float("nan")
        ci_low, ci_high = bootstrap_ci_binary(correct, n_boot=args.n_boot,
                                               seed=args.stats_seed)
        elapsed = pd.to_numeric(g["elapsed_sec"], errors="coerce")
        prompt_tokens = pd.to_numeric(g["prompt_tokens"], errors="coerce")
        generated_tokens = pd.to_numeric(g["generated_tokens"], errors="coerce")
        malformed = g["parser_status"].isin(
            ["empty_output", "no_number", "parse_error", "exception"]).mean()
        first = g.iloc[0]
        rows.append({
            "seed": seed, "benchmark": benchmark, "depth": depth,
            "H_cycles": first["H_cycles"], "L_cycles": first["L_cycles"],
            "passes": first["passes"], "eff_layers": first["eff_layers"],
            "n": int(len(g)), "accuracy": acc,
            "ci_low": ci_low, "ci_high": ci_high,
            "correct": int(np.sum(correct)),
            "malformed_rate": float(malformed),
            "avg_elapsed_sec": float(elapsed.mean()) if elapsed.notna().any()
                               else float("nan"),
            "avg_prompt_tokens": float(prompt_tokens.mean())
                                 if prompt_tokens.notna().any() else float("nan"),
            "avg_generated_tokens": float(generated_tokens.mean())
                                    if generated_tokens.notna().any()
                                    else float("nan"),
            "truncated_rate": float(
                g["truncated"].astype(str).str.lower().eq("true").mean()),
        })
    return pd.DataFrame(rows).sort_values(["benchmark", "seed", "passes"])


def build_aggregate_summary(summary, args):
    rows = []
    for (benchmark, depth), g in summary.groupby(
            ["benchmark", "depth"], dropna=False):
        accs = g["accuracy"].astype(float).values
        first = g.iloc[0]
        lo, hi = bootstrap_ci_numeric(accs, n_boot=args.n_boot,
                                       seed=args.stats_seed)
        rows.append({
            "benchmark": benchmark, "depth": depth,
            "H_cycles": first["H_cycles"], "L_cycles": first["L_cycles"],
            "passes": first["passes"], "eff_layers": first["eff_layers"],
            "num_seeds": int(len(g)),
            "mean_accuracy": float(np.mean(accs)),
            "seed_std": float(np.std(accs, ddof=1)) if len(accs) > 1 else 0.0,
            "seed_ci_low": lo, "seed_ci_high": hi,
            "mean_malformed_rate": float(g["malformed_rate"].astype(float).mean()),
            "mean_elapsed_sec": float(g["avg_elapsed_sec"].astype(float).mean()),
            "mean_truncated_rate": float(g["truncated_rate"].astype(float).mean()),
        })
    return pd.DataFrame(rows).sort_values(["benchmark", "passes"])


def build_pairwise_deltas(per_ex, args):
    rows = []
    depths_present = list(per_ex["depth"].unique())
    comparisons = []
    ref = args.reference_depth
    for d in depths_present:
        if d != ref:
            comparisons.append((d, ref))
    if "half" in depths_present and "shallow" in depths_present:
        comparisons.append(("half", "shallow"))
    seen = set()
    comparisons_unique = []
    for x in comparisons:
        if x not in seen:
            comparisons_unique.append(x)
            seen.add(x)

    for benchmark in sorted(per_ex["benchmark"].unique()):
        bdf = per_ex[per_ex["benchmark"] == benchmark]
        for seed in sorted(bdf["seed"].unique()):
            sdf = bdf[bdf["seed"] == seed]
            for depth_a, depth_b in comparisons_unique:
                a = sdf[sdf["depth"] == depth_a][["example_id", "correct"]]
                b = sdf[sdf["depth"] == depth_b][["example_id", "correct"]]
                if len(a) == 0 or len(b) == 0:
                    continue
                merged = a.merge(b, on="example_id", suffixes=("_a", "_b"))
                if len(merged) == 0:
                    continue
                aa = merged["correct_a"].astype(bool).tolist()
                bb = merged["correct_b"].astype(bool).tolist()
                boot = paired_bootstrap_delta(aa, bb, n_boot=args.n_boot,
                                               seed=args.stats_seed)
                sign = sign_test_p_value(aa, bb)
                rows.append({
                    "benchmark": benchmark, "seed": seed,
                    "depth_a": depth_a, "depth_b": depth_b,
                    "comparison": f"{depth_a} - {depth_b}",
                    "n_paired": int(len(merged)),
                    "acc_a": float(np.mean(aa)), "acc_b": float(np.mean(bb)),
                    "delta": boot["delta"], "ci_low": boot["ci_low"],
                    "ci_high": boot["ci_high"],
                    "bootstrap_p_delta_le_0": boot["p_delta_le_0"],
                    "sign_wins": sign["wins"], "sign_losses": sign["losses"],
                    "sign_ties": sign["ties"],
                    "sign_p_two_sided": sign["p_two_sided"],
                })
    return pd.DataFrame(rows).sort_values(["benchmark", "seed", "comparison"])


def build_gsm8k_parser_audit(per_ex):
    gsm = per_ex[per_ex["benchmark"] == "GSM8K"].copy()
    if len(gsm) == 0:
        return pd.DataFrame()
    rows = []
    for (seed, depth, parser_status), g in gsm.groupby(
            ["seed", "depth", "parser_status"], dropna=False):
        rows.append({
            "seed": seed, "depth": depth, "parser_status": parser_status,
            "n": int(len(g)),
            "accuracy_within_status": float(g["correct"].astype(bool).mean())
                                      if len(g) else float("nan"),
        })
    return pd.DataFrame(rows).sort_values(["seed", "depth", "parser_status"])


# -------------------------
# Plots
# -------------------------

def make_plots(summary, aggregate, pairwise, out_dir):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        plot_dir = out_dir / "plots"
        ensure_dir(plot_dir)

        # Per-benchmark accuracy vs depth
        for benchmark in sorted(aggregate["benchmark"].unique()):
            bdf = aggregate[aggregate["benchmark"] == benchmark].sort_values("passes")
            fig, ax = plt.subplots(figsize=(8, 5))
            ax.errorbar(
                bdf["passes"], bdf["mean_accuracy"],
                yerr=[bdf["mean_accuracy"] - bdf["seed_ci_low"],
                      bdf["seed_ci_high"] - bdf["mean_accuracy"]],
                marker="o", linewidth=2, capsize=4)
            for _, row in bdf.iterrows():
                ax.annotate(row["depth"], (row["passes"], row["mean_accuracy"]),
                            textcoords="offset points", xytext=(5, 5), fontsize=9)
            ax.set_title(f"{benchmark}: accuracy vs recurrence depth")
            ax.set_xlabel("Block passes")
            ax.set_ylabel("Accuracy")
            ax.set_ylim(0, max(1.0, float(bdf["mean_accuracy"].max()) + 0.1))
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(plot_dir / f"{benchmark.lower().replace('-','_')}_accuracy_vs_depth.png",
                        dpi=160)
            plt.close(fig)

        # All benchmarks combined
        fig, ax = plt.subplots(figsize=(10, 6))
        for benchmark in sorted(aggregate["benchmark"].unique()):
            bdf = aggregate[aggregate["benchmark"] == benchmark].sort_values("passes")
            ax.plot(bdf["passes"], bdf["mean_accuracy"], marker="o",
                    linewidth=2, label=benchmark)
        ax.set_title("Accuracy vs recurrence depth")
        ax.set_xlabel("Block passes")
        ax.set_ylabel("Mean accuracy across seeds")
        ax.grid(True, alpha=0.3)
        ax.legend()
        fig.tight_layout()
        fig.savefig(plot_dir / "all_benchmarks_accuracy_vs_depth.png", dpi=180)
        plt.close(fig)

        # GSM8K malformed rate
        gsm = aggregate[aggregate["benchmark"] == "GSM8K"].sort_values("passes")
        if len(gsm):
            fig, ax = plt.subplots(figsize=(8, 5))
            ax.plot(gsm["passes"], gsm["mean_malformed_rate"], marker="o",
                    linewidth=2)
            for _, row in gsm.iterrows():
                ax.annotate(row["depth"],
                            (row["passes"], row["mean_malformed_rate"]),
                            textcoords="offset points", xytext=(5, 5), fontsize=9)
            ax.set_title("GSM8K malformed / unparsable output rate")
            ax.set_xlabel("Block passes")
            ax.set_ylabel("Malformed rate")
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(plot_dir / "gsm8k_malformed_rate.png", dpi=180)
            plt.close(fig)

        log(f"Plots saved under: {plot_dir}")
    except Exception as e:
        log(f"Plotting failed: {repr(e)}")


# -------------------------
# Main
# -------------------------

def parse_args():
    p = argparse.ArgumentParser(
        description="A100 audit for HRM-Text variable-depth inference (v3 fixed)")

    p.add_argument("--model_id", type=str, default="sapientinc/HRM-Text-1B")
    p.add_argument("--out_dir", type=str, default="./hrm_depth_a100_audit_v3")
    p.add_argument("--device", type=str, default="cuda:0")
    p.add_argument("--force_float16", action="store_true")

    p.add_argument("--seeds", type=int, nargs="+", default=[42, 43, 44])
    p.add_argument("--depths", type=str, nargs="+",
                    default=["minimal", "shallow", "half", "default",
                             "deep_H", "maximum"])
    p.add_argument("--reference_depth", type=str, default="default")

    p.add_argument("--n_gsm8k", type=int, default=150)
    p.add_argument("--n_arc", type=int, default=300)
    p.add_argument("--n_hellaswag", type=int, default=300)
    p.add_argument("--n_mmlu", type=int, default=300)
    p.add_argument("--n_boolq", type=int, default=300)

    p.add_argument("--max_new_tokens", type=int, default=180)
    p.add_argument("--max_prompt_len", type=int, default=1536)
    p.add_argument("--max_eval_len", type=int, default=2048)
    p.add_argument("--numeric_atol", type=float, default=1e-2)

    p.add_argument("--n_boot", type=int, default=3000)
    p.add_argument("--stats_seed", type=int, default=123)
    p.add_argument("--checkpoint_every", type=int, default=1)

    p.add_argument("--skip_existing", action="store_true")
    p.add_argument("--smoke", action="store_true")

    args = p.parse_args()

    if args.smoke:
        args.seeds = [42]
        args.depths = ["minimal", "default"]
        args.n_gsm8k = 5
        args.n_arc = 10
        args.n_hellaswag = 10
        args.n_mmlu = 10
        args.n_boolq = 10
        args.n_boot = 200
        args.max_new_tokens = 80

    bad = [d for d in args.depths if d not in DEPTH_SETTINGS]
    if bad:
        raise ValueError(f"Unknown depth(s): {bad}. Valid: {list(DEPTH_SETTINGS)}")

    if args.reference_depth not in args.depths:
        log(f"WARNING: reference depth {args.reference_depth!r} not in --depths.")

    return args


def main():
    args = parse_args()
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)
    save_json(out_dir / "run_config.json", vars(args))
    save_json(out_dir / "depth_settings.json",
              {k: DEPTH_SETTINGS[k] for k in args.depths})

    log("=" * 80)
    log("HRM variable-depth A100 audit (v3 — cache-depth fix)")
    log("=" * 80)
    log(f"Python: {sys.version}")
    log(f"Torch: {torch.__version__}")
    log(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        log(f"CUDA device count: {torch.cuda.device_count()}")
        for i in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(i)
            log(f"  GPU {i}: {props.name}, memory={props.total_memory/1e9:.1f} GB")
    else:
        args.device = "cpu"

    set_global_seed(args.seeds[0] if args.seeds else 42)
    model, tokenizer = load_model_and_tokenizer(
        args.model_id, args.device, force_float16=args.force_float16)
    rec_modules = find_recurrence_module(model)

    # Sanity check
    if "default" in DEPTH_SETTINGS:
        cfg = DEPTH_SETTINGS["default"]
        set_depth(model, rec_modules, cfg["H"], cfg["L"])
        status = verify_depth(model, rec_modules, cfg["H"], cfg["L"])
        log(f"Depth verification at default: ok={status['ok']}")
        sanity, meta = generate_text(model, tokenizer,
                                      "The capital of France is",
                                      max_new_tokens=20, max_prompt_len=256)
        log(f"Sanity generation: The capital of France is{sanity!r}")

    per_example_path = out_dir / "per_example_predictions.csv"
    all_rows: List[Dict[str, Any]] = []

    existing_done = set()
    if args.skip_existing and per_example_path.exists():
        old = pd.read_csv(per_example_path)
        for _, row in old[["seed", "depth", "benchmark"]].drop_duplicates().iterrows():
            existing_done.add((int(row["seed"]), str(row["depth"]),
                               str(row["benchmark"])))
        all_rows.extend(old.to_dict(orient="records"))
        log(f"Loaded existing predictions: {len(old)} rows. "
            f"Completed groups: {len(existing_done)}")

    completed_units = 0
    t_start = time.time()

    for seed in args.seeds:
        set_global_seed(seed)
        benchmarks = load_all_benchmarks(args, seed)

        for depth_name in args.depths:
            depth_cfg = DEPTH_SETTINGS[depth_name]
            log("-" * 80)
            log(f"Evaluating seed={seed}, depth={depth_name} "
                f"H={depth_cfg['H']} L={depth_cfg['L']} "
                f"passes={depth_cfg['passes']}")

            set_depth(model, rec_modules, depth_cfg["H"], depth_cfg["L"])
            depth_status = verify_depth(model, rec_modules,
                                         depth_cfg["H"], depth_cfg["L"])
            if not depth_status["ok"]:
                log(f"WARNING: depth verification failed: {depth_status}")
            else:
                log("Depth verification: ok")

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

            depth_rows = []

            if "GSM8K" in benchmarks:
                key = (seed, depth_name, "GSM8K")
                if key not in existing_done:
                    depth_rows.extend(evaluate_gsm8k(
                        model, tokenizer, benchmarks["GSM8K"],
                        seed, depth_name, depth_cfg, args))
                else:
                    log("Skipping existing GSM8K")

            for benchmark in ["ARC-C", "HellaSwag", "MMLU", "BoolQ"]:
                if benchmark not in benchmarks:
                    continue
                key = (seed, depth_name, benchmark)
                if key in existing_done:
                    log(f"Skipping existing {benchmark}")
                    continue
                depth_rows.extend(evaluate_mcq(
                    model, tokenizer, benchmarks[benchmark],
                    benchmark, seed, depth_name, depth_cfg, args))

            all_rows.extend(depth_rows)
            completed_units += 1

            if depth_rows:
                mini = pd.DataFrame(depth_rows)
                for bench, g in mini.groupby("benchmark"):
                    acc = g["correct"].astype(bool).mean()
                    malformed = g["parser_status"].isin(
                        ["empty_output", "no_number", "parse_error",
                         "exception"]).mean()
                    log(f"  {bench:<10} acc={acc:.1%} n={len(g)} "
                        f"malformed={malformed:.1%}")

            if completed_units % max(1, args.checkpoint_every) == 0:
                pd.DataFrame(all_rows).to_csv(per_example_path, index=False)
                log(f"Checkpoint saved: {per_example_path} ({len(all_rows)} rows)")

            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    total_min = (time.time() - t_start) / 60.0
    log(f"Evaluation finished in {total_min:.1f} min")

    per_ex = pd.DataFrame(all_rows)
    per_ex.to_csv(per_example_path, index=False)
    log(f"Saved per-example predictions: {per_example_path}")

    if len(per_ex) == 0:
        log("No rows collected. Exiting.")
        return

    summary = build_summary(per_ex, args)
    aggregate = build_aggregate_summary(summary, args)
    pairwise = build_pairwise_deltas(per_ex, args)
    gsm_audit = build_gsm8k_parser_audit(per_ex)

    summary.to_csv(out_dir / "summary_by_seed.csv", index=False)
    aggregate.to_csv(out_dir / "summary_across_seeds.csv", index=False)
    pairwise.to_csv(out_dir / "paired_depth_deltas.csv", index=False)
    gsm_audit.to_csv(out_dir / "gsm8k_parser_audit.csv", index=False)

    # GSM8K raw samples for audit
    gsm = per_ex[per_ex["benchmark"] == "GSM8K"].copy()
    if len(gsm):
        samples = []
        for (seed, depth), g in gsm.groupby(["seed", "depth"]):
            fail = g[~g["correct"].astype(bool)].head(8)
            succ = g[g["correct"].astype(bool)].head(5)
            samples.append(pd.concat([fail, succ], axis=0))
        gsm_samples = pd.concat(samples, axis=0) if samples else gsm.head(0)
        sample_cols = ["seed", "depth", "row_index", "correct", "parser_status",
                       "gold", "pred", "matched_text", "question_or_context",
                       "raw_output"]
        gsm_samples[sample_cols].to_csv(
            out_dir / "gsm8k_raw_audit_samples.csv", index=False)

    make_plots(summary, aggregate, pairwise, out_dir)

    print("\n" + "=" * 80)
    print("SUMMARY ACROSS SEEDS")
    print("=" * 80)
    display_cols = ["benchmark", "depth", "passes", "mean_accuracy", "seed_std",
                    "seed_ci_low", "seed_ci_high", "mean_malformed_rate",
                    "mean_elapsed_sec"]
    print(aggregate[display_cols].to_string(
        index=False, float_format=lambda x: f"{x:.4f}"))

    print("\n" + "=" * 80)
    print("PAIRWISE DEPTH DELTAS")
    print("=" * 80)
    if len(pairwise):
        pair_cols = ["benchmark", "seed", "comparison", "n_paired",
                     "acc_a", "acc_b", "delta", "ci_low", "ci_high",
                     "bootstrap_p_delta_le_0", "sign_wins", "sign_losses",
                     "sign_p_two_sided"]
        print(pairwise[pair_cols].to_string(
            index=False, float_format=lambda x: f"{x:.4f}"))
    else:
        print("No pairwise comparisons available.")

    print("\n" + "=" * 80)
    print("OUTPUT FILES")
    print("=" * 80)
    print(f"Per-example predictions: {per_example_path}")
    print(f"Summary by seed:         {out_dir / 'summary_by_seed.csv'}")
    print(f"Summary across seeds:    {out_dir / 'summary_across_seeds.csv'}")
    print(f"Pairwise deltas:         {out_dir / 'paired_depth_deltas.csv'}")
    print(f"GSM8K parser audit:      {out_dir / 'gsm8k_parser_audit.csv'}")
    print(f"GSM8K raw samples:       {out_dir / 'gsm8k_raw_audit_samples.csv'}")
    print(f"Plots:                   {out_dir / 'plots'}")
    print("=" * 80)


if __name__ == "__main__":
    main()