# Not All Recurrence Is Created Equal: Variable-Depth Inference in Recurrent LLMs

Code for reproducing the experiments in our EMNLP 2025 submission.

## Quick Start for Reviewers

To verify the code runs correctly, use the built-in smoke tests (minimal data, ~5 min on A100):

```bash
# 1. Set up environment
pip install -r requirements.txt

# 2. Smoke test HRM-Text-1B (5 GSM8K + 10 each MC benchmark, 2 depths, 1 seed)
python hrm_depth_a100_audit_v3.py --smoke

# 3. Smoke test Huginn-3.5B + Qwen2.5-1.5B baselines
python huggin.py --smoke
```

Each smoke test writes results to its output directory (`./hrm_depth_a100_audit_v3/` and `./huginn_qwen_results/` by default). Check `summary_across_seeds.csv` (HRM) or `summary_aggregate.csv` (baselines) for aggregated accuracy tables, and the `plots/` subfolder for generated figures.

To reproduce the full paper results, see [Full Reproduction](#full-reproduction) below.

## Overview

This repository evaluates how **variable recurrence depth at inference time** affects the accuracy of recurrent language models across five standard NLP benchmarks. We compare:

| Model | Type | Parameters | Depth Control |
|-------|------|------------|---------------|
| HRM-Text-1B (Sapient) | Recurrent | 1B | H-cycles, L-cycles |
| Huginn-3.5B (UMD) | Recurrent | 3.5B | num_steps |
| Qwen2.5-1.5B (Alibaba) | Standard transformer | 1.5B | N/A (baseline) |

**Benchmarks:** GSM8K, ARC-Challenge, HellaSwag, MMLU, BoolQ

## Requirements

- Python 3.10+
- NVIDIA GPU with CUDA support (A100 40GB+ recommended)
- HuggingFace account with access to the models
- Internet connection (models and datasets are downloaded from HuggingFace Hub)

```bash
pip install -r requirements.txt
```

PyTorch must be installed with CUDA support matching your driver. See [pytorch.org](https://pytorch.org/get-started/locally/) for platform-specific install commands.

### Quick start on a cloud GPU (RunPod, etc.)

Deploy with a **PyTorch ≥ 2.5 / CUDA 12.x** template (use **CUDA 12.8 for Blackwell GPUs such as the RTX 5090**; A100/older GPUs work with any recent CUDA 12.x build). PyTorch ≥ 2.5 is required because Huginn uses `torch.nn.attention.flex_attention`. Then:

```bash
pip install -r requirements.txt
python hrm_depth_a100_audit_v3.py --smoke    # HRM-Text-1B
python huggin.py --smoke                      # Huginn-3.5B + Qwen2.5-1.5B
```

The scripts are **self-configuring** and need no manual setup:
- The two models require **different transformers versions**, and each script installs the one it needs at launch and relaunches automatically:
  - `hrm_depth_a100_audit_v3.py` needs **transformers ≥ 5.9.0** (HRM-Text is supported natively from 5.9.0 — there is no remote modeling code for older versions).
  - `huggin.py` needs **transformers 4.49.0** (Huginn's remote modeling code breaks on the 5.x weight-tying refactor).
  - Only the small `transformers` wheel is swapped between runs; PyTorch (≥ 2.5) is shared, so there is no heavy reinstall.
- `hf_transfer` is disabled automatically, so the optional package is not required for downloads.

> **Note:** install dependencies via `requirements.txt`, not `req.txt`. `req.txt` is only a reference snapshot of the original environment and pins an older CUDA build of PyTorch that will not run on newer (Blackwell) GPUs.

## Repository Structure

```
.
├── hrm_depth_a100_audit_v3.py   # HRM-Text-1B variable-depth evaluation
├── huggin.py                    # Huginn-3.5B + Qwen2.5-1.5B baselines
├── requirements.txt             # Python dependencies (minimal)
├── req.txt                      # Full pip freeze from original environment
└── README.md
```

## Full Reproduction

### Step 1: HRM-Text-1B Variable-Depth Evaluation

Evaluates HRM-Text-1B at 6 recurrence depths across all 5 benchmarks with 3 random seeds.

```bash
python hrm_depth_a100_audit_v3.py \
    --model_id sapientinc/HRM-Text-1B \
    --out_dir ./hrm_results \
    --seeds 42 43 44 \
    --depths minimal shallow half default deep_H maximum
```

**Estimated runtime:** ~4-6 hours on A100 40GB.

If the run is interrupted, resume from where it left off:

```bash
python hrm_depth_a100_audit_v3.py --skip_existing --out_dir ./hrm_results
```

**HRM-Text depth configurations:**

| Depth | H-cycles | L-cycles | Block passes | Effective layers |
|-------|----------|----------|--------------|------------------|
| minimal | 1 | 1 | 2 | 16 |
| shallow | 1 | 3 | 4 | 32 |
| half | 2 | 1 | 4 | 32 |
| default | 2 | 3 | 8 | 64 |
| intermediate | 2 | 2 | 6 | 48 |
| deep_H | 4 | 3 | 16 | 128 |
| maximum | 4 | 6 | 28 | 224 |

### Step 2: Huginn + Qwen Baselines

Evaluates Huginn-3.5B at 5 recurrence depths and Qwen2.5-1.5B as a non-recurrent baseline.

```bash
python huggin.py \
    --out_dir ./huginn_qwen_results \
    --seeds 42 43 44
```

**Estimated runtime:** ~3-5 hours on A100 40GB.

To run only one model:

```bash
# Huginn only
python huggin.py --skip_qwen --out_dir ./huginn_results

# Qwen baseline only (~30 min on A100)
python huggin.py --skip_huginn --out_dir ./qwen_baseline
```

### Step 3: Combined Plots

Generate multi-model comparison figures by passing the HRM results to the baseline script:

```bash
python huggin.py \
    --out_dir ./huginn_qwen_results \
    --hrm_results_csv ./hrm_results/per_example_predictions.csv
```

This produces combined accuracy-vs-depth plots for all three models per benchmark under `./huginn_qwen_results/plots/`.

## Output Files

### HRM-Text script (`hrm_depth_a100_audit_v3.py`)

| File | Description |
|------|-------------|
| `per_example_predictions.csv` | Per-example predictions with metadata (gold, pred, correct, latency, etc.) |
| `summary_by_seed.csv` | Accuracy per seed/depth/benchmark with bootstrap 95% CIs |
| `summary_across_seeds.csv` | Aggregated accuracy across seeds with CIs and malformed rates |
| `paired_depth_deltas.csv` | Pairwise depth comparisons with bootstrap deltas and sign tests |
| `gsm8k_parser_audit.csv` | GSM8K answer parsing breakdown by parser status |
| `gsm8k_raw_audit_samples.csv` | Sample model outputs for manual inspection |
| `plots/` | Accuracy vs. depth and malformed rate charts |
| `run_config.json` | Full configuration used for the run |
| `depth_settings.json` | Depth configurations evaluated |

### Baseline script (`huggin.py`)

| File | Description |
|------|-------------|
| `per_example_predictions.csv` | Per-example predictions for Huginn and/or Qwen |
| `summary_by_seed.csv` | Accuracy per seed/depth/benchmark/model |
| `summary_aggregate.csv` | Aggregated accuracy across seeds |
| `plots/` | Combined multi-model accuracy vs. depth charts |
| `run_config.json` | Full configuration used for the run |

## Evaluation Methodology

| Benchmark | Method | Details |
|-----------|--------|---------|
| GSM8K | 2-shot generation | Chain-of-thought prompting, greedy decoding, numeric answer extraction |
| ARC-C | Log-likelihood | Score each answer choice, select highest |
| HellaSwag | Log-likelihood | Score each continuation, select highest |
| MMLU | Log-likelihood | Score each answer choice, select highest |
| BoolQ | Log-likelihood | Score "yes" / "no" continuations |

**Statistical analysis:**
- Bootstrap confidence intervals (3000 resamples, 95% level)
- Paired sign tests for depth comparisons
- Per-example tracking via stable content-based hashing for paired analysis

**Reproducibility guarantees:**
- All data selection is seeded (`--seeds 42 43 44`)
- Example IDs are deterministic content hashes (same seed = same subset)
- Greedy decoding (no sampling randomness)
- Runs checkpoint after each depth and support crash recovery via `--skip_existing`

## Implementation Notes

- **HRM-Text cache fix (v3):** HRM-Text uses unbatched log-likelihood scoring at non-default depths to avoid `IndexError` from cache allocation mismatches. When H-cycles/L-cycles are changed, `config.num_hidden_layers` must be updated to `num_layers_per_stack * H * (L + 1)` — this is handled automatically.
- **Huginn/Qwen batched scoring:** These models support standard batched forward passes, enabling ~4x faster log-likelihood evaluation.
- **KV-cache:** Disabled for HRM-Text during variable-depth evaluation. Huginn uses `num_steps` parameter natively.

## Hardware Requirements

| Model | VRAM (bfloat16) | Notes |
|-------|----------------|-------|
| HRM-Text-1B | ~2 GB | Runs on most modern GPUs |
| Huginn-3.5B | ~7 GB | Needs A100/A6000 or equivalent |
| Qwen2.5-1.5B | ~3 GB | Runs on most modern GPUs |

All experiments in the paper were conducted on NVIDIA A100 40GB GPUs.

## Command-Line Reference

Both scripts accept `--help` for full argument listings:

```bash
python hrm_depth_a100_audit_v3.py --help
python huggin.py --help
```

Key shared arguments:

| Argument | Default | Description |
|----------|---------|-------------|
| `--out_dir` | script-specific | Output directory for all results |
| `--device` | `cuda:0` | GPU device (or `cpu`) |
| `--seeds` | `42 43 44` | Random seeds for data selection |
| `--n_gsm8k` | `150` | Number of GSM8K test examples |
| `--n_arc` | `300` | Number of ARC-Challenge examples |
| `--n_hellaswag` | `300` | Number of HellaSwag examples |
| `--n_mmlu` | `300` | Number of MMLU examples |
| `--n_boolq` | `300` | Number of BoolQ examples |
| `--smoke` | off | Quick test with minimal data |
| `--skip_existing` | off | Resume from checkpoint |

## License

This code is released for research purposes. Please cite the paper if you use this code in your work.
