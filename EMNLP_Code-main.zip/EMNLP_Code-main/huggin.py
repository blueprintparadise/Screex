#!/usr/bin/env python3
"""
huggin.py
=========

Companion to hrm_depth_a100_audit_v3.py.

Evaluates:
  1. Huginn-3.5B at variable recurrence depths (num_steps = 4,8,16,32,64)
  2. Qwen2.5-1.5B (base) as a standard (non-recurrent) transformer baseline

Same benchmarks (GSM8K, ARC-C, HellaSwag, MMLU, BoolQ), same eval methods
(few-shot generation for GSM8K, log-likelihood for MC), same output CSV format.

Results merge directly with HRM-Text data for a combined paper analysis.

Requires A100 40GB+ (Huginn is 3.5B in bf16 = ~7GB).

Usage:
    # Full run
    python huggin.py \
        --out_dir ./huginn_qwen_results \
        --seeds 42 43 44

    # Huginn only
    python huggin.py --skip_qwen --out_dir ./huginn_results

    # Qwen baseline only (fast, ~30 min)
    python huggin.py --skip_huginn --out_dir ./qwen_baseline

    # Smoke test
    python huggin.py --smoke
"""

import argparse
import gc
import hashlib
import json
import math
import os
import random
import re
import sys
import time
import traceback
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

warnings.filterwarnings("ignore")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

# --- Out-of-the-box environment bootstrap --------------------------------
# Huginn-3.5B ships custom modeling code (trust_remote_code) that only runs on
# transformers 4.x; the 5.x weight-tying refactor breaks model loading. Many
# cloud images (and this repo's HRM script) use transformers 5.x, so if a 5.x is
# detected we auto-install the pinned 4.49.0 (with its compatible tokenizers /
# huggingface_hub) and relaunch. This lets `python huggin.py` work with zero
# manual setup regardless of which transformers is currently installed.
# (hrm_depth_a100_audit_v3.py needs the opposite, >=5.9.0, and self-manages it.)
# Also disable hf_transfer so downloads don't require the optional package.
os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "0")
if os.environ.get("_REPRO_BOOTSTRAPPED") != "1":
    try:
        import transformers as _tf
        _tf_major = int(_tf.__version__.split(".")[0])
    except Exception:
        _tf_major = 4
    if _tf_major >= 5:
        import subprocess as _sp
        print(f"[setup] transformers {_tf.__version__} found; installing the "
              f"pinned 4.49.0 required by Huginn, then relaunching...", flush=True)
        _sp.check_call([sys.executable, "-m", "pip", "install", "-q",
                        "transformers==4.49.0", "tokenizers==0.21.4",
                        "huggingface_hub==0.36.2"])
        os.environ["_REPRO_BOOTSTRAPPED"] = "1"
        os.execv(sys.executable, [sys.executable] + sys.argv)
    os.environ["_REPRO_BOOTSTRAPPED"] = "1"

import torch
import numpy as np
import pandas as pd
from datasets import load_dataset
from tqdm.auto import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer


# =========================================================================
# Configuration
# =========================================================================

# Huginn depth settings: num_steps controls recurrence
HUGINN_DEPTHS = {
    "h_4":       {"name": "h_4",       "num_steps": 4,   "label": "Huginn-4"},
    "h_8":       {"name": "h_8",       "num_steps": 8,   "label": "Huginn-8"},
    "h_16":      {"name": "h_16",      "num_steps": 16,  "label": "Huginn-16"},
    "h_32":      {"name": "h_32",      "num_steps": 32,  "label": "Huginn-32"},
    "h_default": {"name": "h_default", "num_steps": 32,  "label": "Huginn-default"},
    "h_64":      {"name": "h_64",      "num_steps": 64,  "label": "Huginn-64"},
}

# Qwen: standard transformer, one depth setting
QWEN_DEPTH = {"name": "qwen_default", "num_steps": 1, "label": "Qwen-1.5B"}


# =========================================================================
# Utilities (shared with HRM script)
# =========================================================================

def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def set_global_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def stable_id(*parts: Any) -> str:
    raw = "||".join(str(p) for p in parts)
    return hashlib.md5(raw.encode("utf-8")).hexdigest()[:12]


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def save_json(path: Path, obj: Any) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def cleanup_cuda():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def normalize_number_str(s: str) -> Optional[float]:
    if s is None:
        return None
    s = str(s).strip().replace(",", "").replace("$", "").replace("%", "")
    frac = re.fullmatch(r"(-?\d+)\s*/\s*(-?\d+)", s)
    if frac:
        den = float(frac.group(2))
        return float(frac.group(1)) / den if den != 0 else None
    try:
        return float(s)
    except Exception:
        return None


# =========================================================================
# Dataset loaders (identical to HRM script for consistency)
# =========================================================================

def select_seeded(ds, n: int, seed: int):
    if n <= 0:
        return []
    n = min(n, len(ds))
    return ds.shuffle(seed=seed).select(range(n))


def load_gsm8k(n: int, seed: int) -> List[Dict]:
    ds = load_dataset("openai/gsm8k", "main", split="test")
    ds = select_seeded(ds, n, seed)
    out = []
    for i, ex in enumerate(ds):
        gold = ex["answer"].split("####")[-1].strip().replace(",", "")
        out.append({"example_id": stable_id("gsm8k", seed, ex["question"], gold),
                     "row_index": i, "question": ex["question"],
                     "answer": gold, "answer_full": ex["answer"]})
    return out


def load_arc_challenge(n: int, seed: int) -> List[Dict]:
    ds = load_dataset("allenai/ai2_arc", "ARC-Challenge", split="test")
    ds = select_seeded(ds, n, seed)
    return [{"example_id": stable_id("arc-c", seed, ex["question"], ex["answerKey"]),
             "row_index": i, "question": ex["question"],
             "choices": list(zip(ex["choices"]["label"], ex["choices"]["text"])),
             "answer": ex["answerKey"]}
            for i, ex in enumerate(ds)]


def load_hellaswag(n: int, seed: int) -> List[Dict]:
    ds = load_dataset("Rowan/hellaswag", split="validation")
    ds = select_seeded(ds, n, seed)
    return [{"example_id": stable_id("hellaswag", seed, ex["ctx"], ex["label"]),
             "row_index": i, "context": ex["ctx"],
             "choices": ex["endings"], "answer": int(ex["label"])}
            for i, ex in enumerate(ds)]


def load_mmlu(n: int, seed: int) -> List[Dict]:
    ds = load_dataset("cais/mmlu", "all", split="test")
    ds = select_seeded(ds, n, seed)
    labels = ["A", "B", "C", "D"]
    return [{"example_id": stable_id("mmlu", seed, ex["question"], ex["answer"],
                                      ex.get("subject", "")),
             "row_index": i, "question": ex["question"],
             "subject": ex.get("subject", ""),
             "choices": list(zip(labels, ex["choices"])),
             "answer": labels[int(ex["answer"])]}
            for i, ex in enumerate(ds)]


def load_boolq(n: int, seed: int) -> List[Dict]:
    ds = load_dataset("google/boolq", split="validation")
    ds = select_seeded(ds, n, seed)
    return [{"example_id": stable_id("boolq", seed, ex["passage"], ex["question"],
                                      ex["answer"]),
             "row_index": i, "passage": ex["passage"],
             "question": ex["question"], "answer": bool(ex["answer"])}
            for i, ex in enumerate(ds)]


def load_all_benchmarks(args, seed: int) -> Dict[str, List[Dict]]:
    log(f"Loading benchmarks for seed={seed}")
    benchmarks = {}
    for name, loader, n in [("GSM8K", load_gsm8k, args.n_gsm8k),
                              ("ARC-C", load_arc_challenge, args.n_arc),
                              ("HellaSwag", load_hellaswag, args.n_hellaswag),
                              ("MMLU", load_mmlu, args.n_mmlu),
                              ("BoolQ", load_boolq, args.n_boolq)]:
        if n <= 0:
            continue
        try:
            t0 = time.time()
            benchmarks[name] = loader(n, seed)
            log(f"  {name}: {len(benchmarks[name])} examples in {time.time()-t0:.1f}s")
        except Exception as e:
            log(f"  WARNING: {name} failed: {e}")
    return benchmarks


# =========================================================================
# MC formatting (identical to HRM script)
# =========================================================================

def fmt_arc(ex):
    ctx = f"Question: {ex['question']}\nAnswer:"
    labels = [l for l, _ in ex["choices"]]
    choices = [f" {t}" for _, t in ex["choices"]]
    return ctx, choices, labels.index(ex["answer"]), labels

def fmt_hellaswag(ex):
    labels = [str(i) for i in range(len(ex["choices"]))]
    return ex["context"], [f" {e}" for e in ex["choices"]], int(ex["answer"]), labels

def fmt_mmlu(ex):
    ctx = f"Question: {ex['question']}\nAnswer:"
    labels = [l for l, _ in ex["choices"]]
    choices = [f" {t}" for _, t in ex["choices"]]
    return ctx, choices, labels.index(ex["answer"]), labels

def fmt_boolq(ex):
    passage = ex["passage"][:1000]
    ctx = f"{passage}\nQuestion: {ex['question']}?\nAnswer:"
    return ctx, [" yes", " no"], 0 if ex["answer"] else 1, ["yes", "no"]

FORMATTERS = {"ARC-C": fmt_arc, "HellaSwag": fmt_hellaswag,
              "MMLU": fmt_mmlu, "BoolQ": fmt_boolq}


# =========================================================================
# GSM8K prompting and parsing
# =========================================================================

def gsm8k_prompt(question: str) -> str:
    return (
        "Solve the math problem. Show the calculation briefly. "
        "End with: The answer is <number>.\n\n"
        "Q: There are 15 trees in the grove. Grove workers will plant trees today. "
        "After they are done, there will be 21 trees. How many trees did the grove "
        "workers plant today?\n"
        "A: There are 21 - 15 = 6 trees planted. The answer is 6.\n\n"
        "Q: If there are 3 cars in the parking lot and 2 more cars arrive, "
        "how many cars are in the parking lot now?\n"
        "A: There are 3 + 2 = 5 cars. The answer is 5.\n\n"
        f"Q: {question}\nA:")

NUMBER_RE = r"[-+]?\d[\d,]*(?:\.\d+)?(?:\s*/\s*[-+]?\d[\d,]*)?"

def parse_gsm8k_answer(output: str):
    if not output or not output.strip():
        return None, "empty_output", None
    txt = output.strip()
    for pat in [rf"[Tt]he answer is\s*({NUMBER_RE})",
                rf"[Aa]nswer\s*[:=]\s*({NUMBER_RE})",
                rf"####\s*({NUMBER_RE})"]:
        m = re.search(pat, txt)
        if m:
            val = normalize_number_str(m.group(1))
            if val is not None:
                return val, "explicit_answer", m.group(1)
    nums = re.findall(NUMBER_RE, txt)
    if nums:
        val = normalize_number_str(nums[-1])
        if val is not None:
            return val, "last_number", nums[-1]
        return None, "parse_error", nums[-1]
    return None, "no_number", None

def compare_numeric(pred, gold_text, atol=1e-2):
    gold = normalize_number_str(gold_text)
    if pred is None or gold is None:
        return False
    return abs(float(pred) - float(gold)) <= atol


# =========================================================================
# Model loading
# =========================================================================

def load_huginn(device="cuda:0"):
    """Load Huginn-3.5B."""
    model_id = "tomg-group-umd/huginn-0125"
    log(f"Loading {model_id}...")
    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    dtype = torch.bfloat16 if device.startswith("cuda") and torch.cuda.is_bf16_supported() else torch.float32
    try:
        model = AutoModelForCausalLM.from_pretrained(
            model_id, dtype=dtype,
            device_map={"": device} if device.startswith("cuda") else None,
            trust_remote_code=True)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(
            model_id, torch_dtype=dtype,
            device_map={"": device} if device.startswith("cuda") else None,
            trust_remote_code=True)
    if not device.startswith("cuda"):
        model.to(device)
    model.eval()
    n = sum(p.numel() for p in model.parameters())
    log(f"  Huginn loaded: {n/1e9:.1f}B params")
    return model, tokenizer


def load_qwen(device="cuda:0"):
    """Load Qwen2.5-1.5B as standard transformer baseline."""
    model_id = "Qwen/Qwen2.5-1.5B"
    log(f"Loading {model_id}...")
    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    dtype = torch.bfloat16 if device.startswith("cuda") and torch.cuda.is_bf16_supported() else torch.float32
    try:
        model = AutoModelForCausalLM.from_pretrained(
            model_id, dtype=dtype,
            device_map={"": device} if device.startswith("cuda") else None,
            trust_remote_code=True)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(
            model_id, torch_dtype=dtype,
            device_map={"": device} if device.startswith("cuda") else None,
            trust_remote_code=True)
    if not device.startswith("cuda"):
        model.to(device)
    model.eval()
    n = sum(p.numel() for p in model.parameters())
    log(f"  Qwen loaded: {n/1e9:.1f}B params")
    return model, tokenizer


# =========================================================================
# Inference: Huginn
# =========================================================================

@torch.inference_mode()
def huginn_generate(model, tokenizer, prompt, num_steps, max_new_tokens=180,
                    max_prompt_len=1536):
    """Generate text with Huginn at a specific recurrence depth."""
    enc = tokenizer(prompt, return_tensors="pt", truncation=True,
                    max_length=max_prompt_len).to(model.device)
    prompt_tokens = int(enc["input_ids"].shape[1])
    t0 = time.time()
    out = model.generate(
        enc["input_ids"],
        max_new_tokens=max_new_tokens,
        do_sample=False,
        num_steps=num_steps,
        pad_token_id=tokenizer.pad_token_id,
        eos_token_id=tokenizer.eos_token_id,
        use_cache=True,
    )
    elapsed = time.time() - t0
    gen_ids = out[0][enc["input_ids"].shape[1]:]
    text = tokenizer.decode(gen_ids, skip_special_tokens=True)
    return text, {"prompt_tokens": prompt_tokens,
                  "generated_tokens": int(gen_ids.shape[0]),
                  "elapsed_sec": elapsed}


@torch.inference_mode()
def huginn_loglikelihood(model, tokenizer, context, continuation, num_steps,
                         max_len=2048):
    """Log-likelihood for one continuation with Huginn at a given depth."""
    ctx_enc = tokenizer(context, add_special_tokens=True)
    ctx_len = len(ctx_enc["input_ids"])

    full = context + continuation
    enc = tokenizer(full, add_special_tokens=True, truncation=True,
                    max_length=max_len, return_tensors="pt").to(model.device)
    input_ids = enc["input_ids"]
    actual_len = int(input_ids.shape[1])

    t0 = time.time()
    outputs = model(input_ids, num_steps=num_steps, use_cache=False)
    elapsed = time.time() - t0

    logits = outputs.logits
    shift_logits = logits[:, :-1, :]
    shift_labels = input_ids[:, 1:]
    log_probs = torch.log_softmax(shift_logits, dim=-1)
    token_lp = log_probs.gather(dim=-1, index=shift_labels.unsqueeze(-1)).squeeze(-1)

    start = max(0, ctx_len - 1)
    end = max(start, actual_len - 1)
    lp_slice = token_lp[0, start:end]

    if lp_slice.numel() == 0:
        return float("-inf"), elapsed
    return float(lp_slice.mean().item()), elapsed


@torch.inference_mode()
def huginn_loglikelihood_batched(model, tokenizer, context, continuations,
                                 num_steps, max_len=2048):
    """
    Log-likelihood for ALL continuations in one batched forward pass.
    ~4x faster than calling huginn_loglikelihood per choice.
    """
    ctx_enc = tokenizer(context, add_special_tokens=True)
    ctx_len = len(ctx_enc["input_ids"])

    full_texts = [context + cont for cont in continuations]
    enc = tokenizer(full_texts, add_special_tokens=True, truncation=True,
                    max_length=max_len, padding=True,
                    return_tensors="pt").to(model.device)

    input_ids = enc["input_ids"]       # [B, seq_len]
    attention_mask = enc["attention_mask"]

    t0 = time.time()
    outputs = model(input_ids, num_steps=num_steps, use_cache=False)
    elapsed = time.time() - t0

    logits = outputs.logits
    shift_logits = logits[:, :-1, :]
    shift_labels = input_ids[:, 1:]
    shift_mask = attention_mask[:, 1:]

    log_probs = torch.log_softmax(shift_logits, dim=-1)
    token_lp = log_probs.gather(dim=-1, index=shift_labels.unsqueeze(-1)).squeeze(-1)

    start = max(0, ctx_len - 1)
    scores = []
    for row_idx in range(len(continuations)):
        actual_len = int(attention_mask[row_idx].sum().item())
        end = max(start, actual_len - 1)
        lp_slice = token_lp[row_idx, start:end]
        mask_slice = shift_mask[row_idx, start:end].bool()
        lp_slice = lp_slice[mask_slice]
        if lp_slice.numel() == 0:
            scores.append(float("-inf"))
        else:
            scores.append(float(lp_slice.mean().item()))

    return scores, elapsed


@torch.inference_mode()
def standard_loglikelihood_batched(model, tokenizer, context, continuations,
                                    max_len=2048):
    """Batched log-likelihood for standard transformers (Qwen etc)."""
    ctx_enc = tokenizer(context, add_special_tokens=True)
    ctx_len = len(ctx_enc["input_ids"])

    full_texts = [context + cont for cont in continuations]
    enc = tokenizer(full_texts, add_special_tokens=True, truncation=True,
                    max_length=max_len, padding=True,
                    return_tensors="pt").to(model.device)

    input_ids = enc["input_ids"]
    attention_mask = enc["attention_mask"]

    t0 = time.time()
    outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    elapsed = time.time() - t0

    logits = outputs.logits
    shift_logits = logits[:, :-1, :]
    shift_labels = input_ids[:, 1:]
    shift_mask = attention_mask[:, 1:]

    log_probs = torch.log_softmax(shift_logits, dim=-1)
    token_lp = log_probs.gather(dim=-1, index=shift_labels.unsqueeze(-1)).squeeze(-1)

    start = max(0, ctx_len - 1)
    scores = []
    for row_idx in range(len(continuations)):
        actual_len = int(attention_mask[row_idx].sum().item())
        end = max(start, actual_len - 1)
        lp_slice = token_lp[row_idx, start:end]
        mask_slice = shift_mask[row_idx, start:end].bool()
        lp_slice = lp_slice[mask_slice]
        if lp_slice.numel() == 0:
            scores.append(float("-inf"))
        else:
            scores.append(float(lp_slice.mean().item()))

    return scores, elapsed


def evaluate_mcq_batched(model, tokenizer, data, benchmark, seed, depth_name,
                          depth_cfg, batched_ll_fn, model_name, args):
    """MC evaluation using batched log-likelihood (all choices in one forward pass)."""
    rows = []
    formatter = FORMATTERS[benchmark]

    for ex in tqdm(data, desc=f"{benchmark} {model_name} {depth_name}",
                   leave=False):
        try:
            context, choices, gold_idx, labels = formatter(ex)
            scores, elapsed = batched_ll_fn(model, tokenizer, context, choices)

            pred_idx = int(np.argmax(scores))
            sorted_s = sorted(scores, reverse=True)
            gap = sorted_s[0] - sorted_s[1] if len(sorted_s) > 1 else 0.0

            rows.append(make_row(
                seed, benchmark, depth_name, depth_cfg, ex["example_id"],
                ex["row_index"], labels[gold_idx], labels[pred_idx],
                labels[pred_idx], pred_idx == gold_idx, "mcq_ll_batched", "",
                gap, "", 0, elapsed, False, context[:1000],
                json.dumps({"scores": scores, "labels": labels}), model_name))
        except Exception as e:
            rows.append(make_row(
                seed, benchmark, depth_name, depth_cfg,
                ex.get("example_id", ""), ex.get("row_index", ""),
                "", "", "", False, "exception", "", "", "", 0, "", "",
                "", f"EXCEPTION: {repr(e)}\n{traceback.format_exc()}",
                model_name))
    return rows


# =========================================================================
# Inference: Qwen (standard transformer)
# =========================================================================

@torch.inference_mode()
def standard_generate(model, tokenizer, prompt, max_new_tokens=180,
                      max_prompt_len=1536):
    """Generate text with a standard transformer."""
    enc = tokenizer(prompt, return_tensors="pt", truncation=True,
                    max_length=max_prompt_len).to(model.device)
    prompt_tokens = int(enc["input_ids"].shape[1])
    t0 = time.time()
    out = model.generate(
        **enc, max_new_tokens=max_new_tokens, do_sample=False,
        pad_token_id=tokenizer.pad_token_id)
    elapsed = time.time() - t0
    gen_ids = out[0][enc["input_ids"].shape[1]:]
    text = tokenizer.decode(gen_ids, skip_special_tokens=True)
    return text, {"prompt_tokens": prompt_tokens,
                  "generated_tokens": int(gen_ids.shape[0]),
                  "elapsed_sec": elapsed}


@torch.inference_mode()
def standard_loglikelihood(model, tokenizer, context, continuation,
                           max_len=2048):
    """Log-likelihood for one continuation with a standard transformer."""
    ctx_enc = tokenizer(context, add_special_tokens=True)
    ctx_len = len(ctx_enc["input_ids"])

    full = context + continuation
    enc = tokenizer(full, add_special_tokens=True, truncation=True,
                    max_length=max_len, return_tensors="pt").to(model.device)
    input_ids = enc["input_ids"]
    actual_len = int(input_ids.shape[1])

    t0 = time.time()
    outputs = model(input_ids=input_ids)
    elapsed = time.time() - t0

    logits = outputs.logits
    shift_logits = logits[:, :-1, :]
    shift_labels = input_ids[:, 1:]
    log_probs = torch.log_softmax(shift_logits, dim=-1)
    token_lp = log_probs.gather(dim=-1, index=shift_labels.unsqueeze(-1)).squeeze(-1)

    start = max(0, ctx_len - 1)
    end = max(start, actual_len - 1)
    lp_slice = token_lp[0, start:end]

    if lp_slice.numel() == 0:
        return float("-inf"), elapsed
    return float(lp_slice.mean().item()), elapsed


# =========================================================================
# Evaluation functions
# =========================================================================

def make_row(seed, benchmark, depth_name, depth_cfg, example_id, row_index,
             gold, pred, pred_label, correct, parser_status, matched_text,
             score_gap, prompt_tokens, generated_tokens, elapsed_sec,
             truncated, question_or_context, raw_output, model_name):
    """Build a result row compatible with HRM script output."""
    return {
        "seed": seed, "benchmark": benchmark, "depth": depth_name,
        "H_cycles": depth_cfg.get("num_steps", ""),
        "L_cycles": "", "passes": depth_cfg.get("num_steps", 1),
        "eff_layers": depth_cfg.get("num_steps", 1),
        "example_id": example_id, "row_index": row_index,
        "gold": gold, "pred": pred, "pred_label": pred_label,
        "correct": bool(correct), "parser_status": parser_status,
        "matched_text": matched_text or "", "score_gap": score_gap,
        "prompt_tokens": prompt_tokens, "generated_tokens": generated_tokens,
        "elapsed_sec": elapsed_sec, "truncated": truncated,
        "question_or_context": question_or_context,
        "raw_output": raw_output, "model_name": model_name,
    }


def evaluate_gsm8k_generic(model, tokenizer, data, seed, depth_name, depth_cfg,
                            generate_fn, model_name, args):
    """Evaluate GSM8K with any model's generation function."""
    rows = []
    for ex in tqdm(data, desc=f"GSM8K {model_name} {depth_name}", leave=False):
        prompt = gsm8k_prompt(ex["question"])
        try:
            output, meta = generate_fn(model, tokenizer, prompt)
            pred_float, parser_status, matched_text = parse_gsm8k_answer(output)
            correct = compare_numeric(pred_float, ex["answer"])
            rows.append(make_row(
                seed, "GSM8K", depth_name, depth_cfg, ex["example_id"],
                ex["row_index"], ex["answer"],
                "" if pred_float is None else pred_float,
                "" if pred_float is None else str(pred_float),
                correct, parser_status, matched_text, "",
                meta["prompt_tokens"], meta["generated_tokens"],
                meta["elapsed_sec"], False, ex["question"], output, model_name))
        except Exception as e:
            rows.append(make_row(
                seed, "GSM8K", depth_name, depth_cfg, ex["example_id"],
                ex["row_index"], ex["answer"], "", "", False, "exception",
                "", "", "", "", "", "", ex["question"],
                f"EXCEPTION: {repr(e)}\n{traceback.format_exc()}", model_name))
    return rows


def evaluate_mcq_generic(model, tokenizer, data, benchmark, seed, depth_name,
                          depth_cfg, ll_fn, model_name, args):
    """Evaluate MC benchmark with any model's log-likelihood function."""
    rows = []
    formatter = FORMATTERS[benchmark]

    for ex in tqdm(data, desc=f"{benchmark} {model_name} {depth_name}",
                   leave=False):
        try:
            context, choices, gold_idx, labels = formatter(ex)
            scores = []
            total_elapsed = 0.0
            for cont in choices:
                score, elapsed = ll_fn(model, tokenizer, context, cont)
                scores.append(score)
                total_elapsed += elapsed

            pred_idx = int(np.argmax(scores))
            sorted_s = sorted(scores, reverse=True)
            gap = sorted_s[0] - sorted_s[1] if len(sorted_s) > 1 else 0.0

            rows.append(make_row(
                seed, benchmark, depth_name, depth_cfg, ex["example_id"],
                ex["row_index"], labels[gold_idx], labels[pred_idx],
                labels[pred_idx], pred_idx == gold_idx, "mcq_ll", "",
                gap, "", 0, total_elapsed, False, context[:1000],
                json.dumps({"scores": scores, "labels": labels}), model_name))
        except Exception as e:
            rows.append(make_row(
                seed, benchmark, depth_name, depth_cfg,
                ex.get("example_id", ""), ex.get("row_index", ""),
                "", "", "", False, "exception", "", "", "", 0, "", "",
                "", f"EXCEPTION: {repr(e)}\n{traceback.format_exc()}",
                model_name))
    return rows


# =========================================================================
# Statistics (same as HRM script)
# =========================================================================

def bootstrap_ci(values, n_boot=3000, seed=123, alpha=0.05):
    arr = np.asarray(values, dtype=float)
    if len(arr) == 0:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    means = [float(arr[rng.integers(0, len(arr), size=len(arr))].mean())
             for _ in range(n_boot)]
    return (float(np.percentile(means, 100*alpha/2)),
            float(np.percentile(means, 100*(1-alpha/2))))


def build_summary(per_ex, n_boot=3000, stats_seed=123):
    rows = []
    for (seed, benchmark, depth, model_name), g in per_ex.groupby(
            ["seed", "benchmark", "depth", "model_name"], dropna=False):
        correct = g["correct"].astype(bool).tolist()
        acc = float(np.mean(correct)) if correct else float("nan")
        ci_lo, ci_hi = bootstrap_ci(correct, n_boot=n_boot, seed=stats_seed)
        elapsed = pd.to_numeric(g["elapsed_sec"], errors="coerce")
        malformed = g["parser_status"].isin(
            ["empty_output", "no_number", "parse_error", "exception"]).mean()
        first = g.iloc[0]
        rows.append({
            "seed": seed, "benchmark": benchmark, "depth": depth,
            "model_name": model_name,
            "passes": first["passes"], "n": len(g),
            "accuracy": acc, "ci_low": ci_lo, "ci_high": ci_hi,
            "correct": int(np.sum(correct)),
            "malformed_rate": float(malformed),
            "avg_elapsed_sec": float(elapsed.mean()) if elapsed.notna().any()
                               else float("nan"),
        })
    return pd.DataFrame(rows).sort_values(["model_name", "benchmark", "seed", "passes"])


def build_aggregate(summary):
    rows = []
    for (benchmark, depth, model_name), g in summary.groupby(
            ["benchmark", "depth", "model_name"], dropna=False):
        accs = g["accuracy"].astype(float).values
        first = g.iloc[0]
        rows.append({
            "benchmark": benchmark, "depth": depth,
            "model_name": model_name, "passes": first["passes"],
            "num_seeds": len(g),
            "mean_accuracy": float(np.mean(accs)),
            "seed_std": float(np.std(accs, ddof=1)) if len(accs) > 1 else 0.0,
            "mean_malformed_rate": float(g["malformed_rate"].astype(float).mean()),
            "mean_elapsed_sec": float(g["avg_elapsed_sec"].astype(float).mean()),
        })
    return pd.DataFrame(rows).sort_values(["model_name", "benchmark", "passes"])


# =========================================================================
# Plotting
# =========================================================================

def make_combined_plot(hrm_agg, huginn_agg, qwen_agg, out_dir):
    """Generate the combined multi-model depth plot."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        ensure_dir(out_dir / "plots")

        for benchmark in ["GSM8K", "ARC-C", "HellaSwag", "MMLU", "BoolQ"]:
            fig, ax = plt.subplots(figsize=(9, 6))

            # HRM-Text
            if hrm_agg is not None:
                bdf = hrm_agg[hrm_agg["benchmark"] == benchmark].sort_values("passes")
                if len(bdf):
                    ax.plot(bdf["passes"], bdf["mean_accuracy"]*100, "o-",
                            linewidth=2, markersize=7, label="HRM-Text-1B",
                            color="#E74C3C")

            # Huginn
            if huginn_agg is not None:
                bdf = huginn_agg[huginn_agg["benchmark"] == benchmark].sort_values("passes")
                if len(bdf):
                    ax.plot(bdf["passes"], bdf["mean_accuracy"]*100, "s-",
                            linewidth=2, markersize=7, label="Huginn-3.5B",
                            color="#3498DB")

            # Qwen (horizontal line)
            if qwen_agg is not None:
                bdf = qwen_agg[qwen_agg["benchmark"] == benchmark]
                if len(bdf):
                    acc = bdf["mean_accuracy"].iloc[0] * 100
                    ax.axhline(y=acc, color="#2ECC71", linewidth=2,
                               linestyle="--", label=f"Qwen-1.5B ({acc:.1f}%)")

            ax.set_xlabel("Recurrence Depth (passes / num_steps)", fontsize=12)
            ax.set_ylabel("Accuracy (%)", fontsize=12)
            ax.set_title(f"{benchmark}: Variable-Depth Comparison", fontsize=14)
            ax.legend(fontsize=10)
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(out_dir / "plots" / f"{benchmark.lower().replace('-','_')}_combined.png",
                        dpi=160)
            plt.close(fig)

        log(f"Combined plots saved to {out_dir / 'plots'}")
    except Exception as e:
        log(f"Plotting failed: {e}")


# =========================================================================
# Main
# =========================================================================

def parse_args():
    p = argparse.ArgumentParser(description="Huginn + Qwen baselines for HRM depth paper")

    p.add_argument("--out_dir", type=str, default="./huginn_qwen_results")
    p.add_argument("--device", type=str, default="cuda:0")
    p.add_argument("--seeds", type=int, nargs="+", default=[42, 43, 44])

    p.add_argument("--huginn_depths", type=str, nargs="+",
                    default=["h_4", "h_8", "h_16", "h_32", "h_64"])
    p.add_argument("--skip_huginn", action="store_true")
    p.add_argument("--skip_qwen", action="store_true")

    p.add_argument("--n_gsm8k", type=int, default=150)
    p.add_argument("--n_arc", type=int, default=300)
    p.add_argument("--n_hellaswag", type=int, default=300)
    p.add_argument("--n_mmlu", type=int, default=300)
    p.add_argument("--n_boolq", type=int, default=300)

    p.add_argument("--max_new_tokens", type=int, default=180)
    p.add_argument("--max_eval_len", type=int, default=2048)

    p.add_argument("--hrm_results_csv", type=str, default=None,
                    help="Path to HRM per_example_predictions.csv for combined plots")

    p.add_argument("--skip_existing", action="store_true")
    p.add_argument("--smoke", action="store_true")

    args = p.parse_args()

    if args.smoke:
        args.seeds = [42]
        args.huginn_depths = ["h_4", "h_16"]
        args.n_gsm8k = 10
        args.n_arc = 20
        args.n_hellaswag = 20
        args.n_mmlu = 20
        args.n_boolq = 20
        args.max_new_tokens = 80

    return args


def main():
    args = parse_args()
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)
    save_json(out_dir / "run_config.json", vars(args))

    log("=" * 80)
    log("Huginn + Qwen Baseline Evaluation")
    log("=" * 80)
    log(f"Torch: {torch.__version__}")
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(i)
            log(f"  GPU {i}: {props.name}, {props.total_memory/1e9:.1f} GB")

    per_example_path = out_dir / "per_example_predictions.csv"
    all_rows = []

    existing_done = set()
    if args.skip_existing and per_example_path.exists():
        old = pd.read_csv(per_example_path)
        for _, row in old[["seed", "depth", "benchmark", "model_name"]].drop_duplicates().iterrows():
            existing_done.add((int(row["seed"]), str(row["depth"]),
                               str(row["benchmark"]), str(row["model_name"])))
        all_rows.extend(old.to_dict(orient="records"))
        log(f"Loaded existing: {len(old)} rows, {len(existing_done)} completed groups")

    t_total = time.time()

    # ===================== HUGINN =====================
    if not args.skip_huginn:
        log("\n" + "=" * 60)
        log("  HUGINN-3.5B VARIABLE-DEPTH EVALUATION")
        log("=" * 60)

        huginn_model, huginn_tok = load_huginn(args.device)

        # Sanity check
        log("Sanity check (num_steps=16):")
        text, _ = huginn_generate(huginn_model, huginn_tok,
                                   "The capital of France is", num_steps=16)
        log(f"  '{text[:80]}'")

        for seed in args.seeds:
            set_global_seed(seed)
            benchmarks = load_all_benchmarks(args, seed)

            for depth_name in args.huginn_depths:
                if depth_name not in HUGINN_DEPTHS:
                    log(f"Unknown Huginn depth: {depth_name}")
                    continue
                dcfg = HUGINN_DEPTHS[depth_name]
                ns = dcfg["num_steps"]

                log("-" * 60)
                log(f"Huginn seed={seed}, depth={depth_name}, num_steps={ns}")

                depth_rows = []

                # GSM8K (generation)
                if "GSM8K" in benchmarks:
                    key = (seed, depth_name, "GSM8K", "Huginn-3.5B")
                    if key not in existing_done:
                        gen_fn = lambda m, t, p, _ns=ns: huginn_generate(m, t, p, _ns,
                                    max_new_tokens=args.max_new_tokens)
                        depth_rows.extend(evaluate_gsm8k_generic(
                            huginn_model, huginn_tok, benchmarks["GSM8K"],
                            seed, depth_name, dcfg, gen_fn, "Huginn-3.5B", args))
                        cleanup_cuda()

                # MC benchmarks (batched log-likelihood — 4x faster)
                for bench in ["ARC-C", "HellaSwag", "MMLU", "BoolQ"]:
                    if bench not in benchmarks:
                        continue
                    key = (seed, depth_name, bench, "Huginn-3.5B")
                    if key in existing_done:
                        continue
                    bll_fn = lambda m, t, ctx, conts, _ns=ns: huginn_loglikelihood_batched(
                                m, t, ctx, conts, _ns, max_len=args.max_eval_len)
                    depth_rows.extend(evaluate_mcq_batched(
                        huginn_model, huginn_tok, benchmarks[bench],
                        bench, seed, depth_name, dcfg, bll_fn,
                        "Huginn-3.5B", args))
                    cleanup_cuda()

                all_rows.extend(depth_rows)

                # Print mini summary
                if depth_rows:
                    mini = pd.DataFrame(depth_rows)
                    for bench, g in mini.groupby("benchmark"):
                        acc = g["correct"].astype(bool).mean()
                        mal = g["parser_status"].isin(
                            ["empty_output","no_number","parse_error","exception"]).mean()
                        log(f"  {bench:<10} acc={acc:.1%} n={len(g)} malformed={mal:.1%}")

                # Checkpoint
                pd.DataFrame(all_rows).to_csv(per_example_path, index=False)
                cleanup_cuda()

        del huginn_model, huginn_tok
        cleanup_cuda()
        log("Huginn evaluation complete.\n")

    # ===================== QWEN =====================
    if not args.skip_qwen:
        log("\n" + "=" * 60)
        log("  QWEN-1.5B STANDARD TRANSFORMER BASELINE")
        log("=" * 60)

        qwen_model, qwen_tok = load_qwen(args.device)

        # Sanity check
        log("Sanity check:")
        text, _ = standard_generate(qwen_model, qwen_tok,
                                     "The capital of France is")
        log(f"  '{text[:80]}'")

        dcfg = QWEN_DEPTH

        for seed in args.seeds:
            set_global_seed(seed)
            benchmarks = load_all_benchmarks(args, seed)

            log("-" * 60)
            log(f"Qwen seed={seed}")

            depth_rows = []

            # GSM8K
            if "GSM8K" in benchmarks:
                key = (seed, "qwen_default", "GSM8K", "Qwen-1.5B")
                if key not in existing_done:
                    gen_fn = lambda m, t, p: standard_generate(m, t, p,
                                max_new_tokens=args.max_new_tokens)
                    depth_rows.extend(evaluate_gsm8k_generic(
                        qwen_model, qwen_tok, benchmarks["GSM8K"],
                        seed, "qwen_default", dcfg, gen_fn, "Qwen-1.5B", args))
                    cleanup_cuda()

            # MC (batched)
            for bench in ["ARC-C", "HellaSwag", "MMLU", "BoolQ"]:
                if bench not in benchmarks:
                    continue
                key = (seed, "qwen_default", bench, "Qwen-1.5B")
                if key in existing_done:
                    continue
                bll_fn = lambda m, t, ctx, conts: standard_loglikelihood_batched(
                            m, t, ctx, conts, max_len=args.max_eval_len)
                depth_rows.extend(evaluate_mcq_batched(
                    qwen_model, qwen_tok, benchmarks[bench],
                    bench, seed, "qwen_default", dcfg, bll_fn,
                    "Qwen-1.5B", args))
                cleanup_cuda()

            all_rows.extend(depth_rows)

            if depth_rows:
                mini = pd.DataFrame(depth_rows)
                for bench, g in mini.groupby("benchmark"):
                    acc = g["correct"].astype(bool).mean()
                    log(f"  {bench:<10} acc={acc:.1%} n={len(g)}")

            pd.DataFrame(all_rows).to_csv(per_example_path, index=False)
            cleanup_cuda()

        del qwen_model, qwen_tok
        cleanup_cuda()
        log("Qwen evaluation complete.\n")

    # ===================== SUMMARY =====================
    total_time = time.time() - t_total
    log(f"Total time: {total_time/60:.1f} min")

    per_ex = pd.DataFrame(all_rows)
    per_ex.to_csv(per_example_path, index=False)

    if len(per_ex) == 0:
        log("No results. Exiting.")
        return

    summary = build_summary(per_ex)
    aggregate = build_aggregate(summary)

    summary.to_csv(out_dir / "summary_by_seed.csv", index=False)
    aggregate.to_csv(out_dir / "summary_aggregate.csv", index=False)

    # Print results
    print("\n" + "=" * 80)
    print("RESULTS")
    print("=" * 80)
    display = ["model_name", "benchmark", "depth", "passes",
                "mean_accuracy", "seed_std", "mean_malformed_rate"]
    print(aggregate[display].to_string(
        index=False, float_format=lambda x: f"{x:.4f}"))

    # Combined plot with HRM data if available
    hrm_agg = None
    if args.hrm_results_csv and Path(args.hrm_results_csv).exists():
        hrm_per = pd.read_csv(args.hrm_results_csv)
        hrm_per["model_name"] = "HRM-Text-1B"
        hrm_summary = build_summary(hrm_per)
        hrm_agg = build_aggregate(hrm_summary)
        log("Loaded HRM-Text results for combined plots.")

    huginn_agg = aggregate[aggregate["model_name"] == "Huginn-3.5B"] \
                 if "Huginn-3.5B" in aggregate["model_name"].values else None
    qwen_agg = aggregate[aggregate["model_name"] == "Qwen-1.5B"] \
               if "Qwen-1.5B" in aggregate["model_name"].values else None

    make_combined_plot(hrm_agg, huginn_agg, qwen_agg, out_dir)

    print("\n" + "=" * 80)
    print("OUTPUT FILES")
    print("=" * 80)
    print(f"Per-example:  {per_example_path}")
    print(f"Summary:      {out_dir / 'summary_by_seed.csv'}")
    print(f"Aggregate:    {out_dir / 'summary_aggregate.csv'}")
    print(f"Plots:        {out_dir / 'plots'}")
    print("=" * 80)


if __name__ == "__main__":
    main()